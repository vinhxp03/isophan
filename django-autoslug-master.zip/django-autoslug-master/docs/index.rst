.. include:: ../README.rst

See detailed documentation with real-world examples:

.. toctree::
   :maxdepth: 2

   fields
   settings
   contributors
   changes

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

