Settings
========

.. automodule:: autoslug.settings
   :members:
